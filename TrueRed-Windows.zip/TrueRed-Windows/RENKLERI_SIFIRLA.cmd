@echo off
start "" "%~dp0TrueRed.exe" --reset
