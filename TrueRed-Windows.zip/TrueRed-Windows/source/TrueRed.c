#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0602
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <wchar.h>
#include "color.h"

#define APPCLASS L"TrueRedControllerWindowV1"
#define SETTINGS L"Software\\TrueRedController"
#define RUNKEY L"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define RUNNAME L"TrueRedController"
#define TRAYMSG (WM_APP + 1)
#define RESETMSG (WM_APP + 2)
#define ID_SLIDER 101
#define ID_NORMAL 102
#define ID_RED 103
#define ID_TRAY 104
#define ID_STARTUP 105
#define ID_SHOW 106
#define ID_EXIT 107
#define ID_HOTKEY 108

typedef struct { float v[25]; } ColorMatrix;
typedef BOOL (WINAPI *MagInitFn)(void);
typedef BOOL (WINAPI *MagColorFn)(ColorMatrix*);
static MagInitFn magInit, magUninit;
static MagColorFn magSet, magGet;
static HMODULE magDll;
static BOOL initialized, originalValid, trayAdded, hotkeyOK, changing;
static ColorMatrix original;
static HWND mainWindow, slider, percentLabel, statusLabel, startupBox;
static HBRUSH background;
static HFONT font, titleFont, numberFont, smallFont;
static HICON icon;
static HINSTANCE instance;
static int intensity, lastNonzero = 100;
static NOTIFYICONDATAW tray;
static UINT taskbarCreated;
static const COLORREF bg = RGB(20,22,27), fg = RGB(237,238,243);

static int scale(int n) {
    HDC dc = GetDC(NULL);
    int dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(NULL,dc);
    return MulDiv(n,dpi,96);
}
static void errorBox(const wchar_t *message) {
    MessageBoxW(mainWindow,message,L"True Red",MB_OK|MB_ICONERROR);
}
static DWORD readIntensity(void) {
    DWORD v = 0, size = sizeof(v);
    if (RegGetValueW(HKEY_CURRENT_USER,SETTINGS,L"Intensity",RRF_RT_REG_DWORD,NULL,&v,&size) != ERROR_SUCCESS) v = 0;
    return v <= 100 ? v : 0;
}
static void saveIntensity(void) {
    HKEY key;
    DWORD v = (DWORD)intensity;
    if (RegCreateKeyExW(HKEY_CURRENT_USER,SETTINGS,0,NULL,0,KEY_SET_VALUE,NULL,&key,NULL) == ERROR_SUCCESS) {
        RegSetValueExW(key,L"Intensity",0,REG_DWORD,(BYTE*)&v,sizeof(v));
        RegCloseKey(key);
    }
}
static BOOL isStartupEnabled(void) {
    wchar_t current[32768], own[32768], expected[32780];
    DWORD bytes=sizeof(current);
    if (!GetModuleFileNameW(NULL,own,32768)) return FALSE;
    swprintf(expected,32780,L"\"%ls\" --tray",own);
    return RegGetValueW(HKEY_CURRENT_USER,RUNKEY,RUNNAME,RRF_RT_REG_SZ,NULL,current,&bytes)==ERROR_SUCCESS && wcscmp(current,expected)==0;
}
static void setStartup(BOOL enabled) {
    HKEY key;
    LONG result;
    wchar_t path[32768], command[32780];
    result=RegCreateKeyExW(HKEY_CURRENT_USER,RUNKEY,0,NULL,0,KEY_SET_VALUE,NULL,&key,NULL);
    if (result==ERROR_SUCCESS) {
        if (enabled) {
            DWORD count=GetModuleFileNameW(NULL,path,32768);
            if (!count || count >= 32768) result=ERROR_INSUFFICIENT_BUFFER;
            else {
                swprintf(command,32780,L"\"%ls\" --tray",path);
                result=RegSetValueExW(key,RUNNAME,0,REG_SZ,(BYTE*)command,(DWORD)((wcslen(command)+1)*sizeof(wchar_t)));
            }
        } else {
            result=RegDeleteValueW(key,RUNNAME);
            if (result==ERROR_FILE_NOT_FOUND) result=ERROR_SUCCESS;
        }
        RegCloseKey(key);
    }
    if (result!=ERROR_SUCCESS) errorBox(L"Windows başlangıç ayarı kaydedilemedi.");
    SendMessageW(startupBox,BM_SETCHECK,isStartupEnabled()?BST_CHECKED:BST_UNCHECKED,0);
}
static BOOL initEngine(void) {
    /* Load only the Windows system DLL; never a DLL beside the portable EXE. */
    wchar_t path[MAX_PATH];
    if (!GetSystemDirectoryW(path,MAX_PATH-32)) return FALSE;
    wcscat(path,L"\\Magnification.dll");
    magDll=LoadLibraryW(path);
    if (!magDll) return FALSE;
    magInit=(MagInitFn)(void*)GetProcAddress(magDll,"MagInitialize");
    magUninit=(MagInitFn)(void*)GetProcAddress(magDll,"MagUninitialize");
    magSet=(MagColorFn)(void*)GetProcAddress(magDll,"MagSetFullscreenColorEffect");
    magGet=(MagColorFn)(void*)GetProcAddress(magDll,"MagGetFullscreenColorEffect");
    if (!magInit||!magUninit||!magSet||!magGet) return FALSE;
    initialized=magInit();
    if (!initialized) return FALSE;
    originalValid=magGet(&original);
    return originalValid;
}
static void updateLabels(void) {
    wchar_t text[256];
    swprintf(text,256,L"%%%d",intensity);
    SetWindowTextW(percentLabel,text);
    if (intensity==0) wcscpy(text,L"Normal renkler • Filtre kapalı");
    else if (intensity==100) wcscpy(text,L"Tam kırmızı • Dönüşümde yeşil ve mavi: 0");
    else swprintf(text,256,L"Kırmızı geçişi: %%%d",intensity);
    if (!hotkeyOK) wcscat(text,L"  |  Kısayol kullanılamıyor");
    SetWindowTextW(statusLabel,text);
    if (trayAdded) {
        swprintf(tray.szTip,128,L"True Red • %%%d",intensity);
        tray.uFlags=NIF_TIP;
        Shell_NotifyIconW(NIM_MODIFY,&tray);
    }
}
static BOOL applyIntensity(int value, BOOL save) {
    ColorMatrix next;
    if (value<0) value=0;
    if (value>100) value=100;
    make_color(next.v,value);
    if (!magSet(&next)) {
        changing=TRUE;
        SendMessageW(slider,TBM_SETPOS,TRUE,intensity);
        changing=FALSE;
        SetWindowTextW(statusLabel,L"Filtre uygulanamadı. Ekran sürücüsü / oturumu desteklemiyor olabilir.");
        return FALSE;
    }
    intensity=value;
    if (value>0) lastNonzero=value;
    changing=TRUE;
    SendMessageW(slider,TBM_SETPOS,TRUE,value);
    changing=FALSE;
    updateLabels();
    if (save) saveIntensity();
    return TRUE;
}
static void restore(void) {
    if (initialized && originalValid) magSet(&original);
}
static void showWindow(void) {
    ShowWindow(mainWindow,SW_RESTORE);
    SetForegroundWindow(mainWindow);
}
static void addTray(void) {
    ZeroMemory(&tray,sizeof(tray));
    tray.cbSize=sizeof(tray); tray.hWnd=mainWindow; tray.uID=1;
    tray.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
    tray.uCallbackMessage=TRAYMSG; tray.hIcon=icon;
    wcscpy(tray.szTip,L"True Red");
    trayAdded=Shell_NotifyIconW(NIM_ADD,&tray);
    if (!trayAdded) showWindow();
}
static HWND control(const wchar_t *cls,const wchar_t *text,DWORD style,int x,int y,int w,int h,int id,HFONT f) {
    HWND c=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,scale(x),scale(y),scale(w),scale(h),mainWindow,(HMENU)(INT_PTR)id,instance,NULL);
    SendMessageW(c,WM_SETFONT,(WPARAM)f,TRUE);
    return c;
}
static LRESULT CALLBACK windowProc(HWND hwnd,UINT msg,WPARAM w,LPARAM l) {
    if (msg==taskbarCreated && taskbarCreated!=0) { addTray(); updateLabels(); return 0; }
    switch(msg) {
    case WM_CREATE: {
        mainWindow=hwnd;
        control(L"STATIC",L"TRUE RED",0,28,22,270,42,0,titleFont);
        control(L"STATIC",L"Ekran rengini tek hareketle değiştir.",0,30,70,430,25,0,font);
        control(L"STATIC",L"Kırmızı yoğunluğu",0,30,128,285,30,0,font);
        percentLabel=control(L"STATIC",L"%0",SS_RIGHT,340,111,135,56,0,numberFont);
        slider=control(TRACKBAR_CLASSW,L"",TBS_HORZ|TBS_NOTICKS|WS_TABSTOP,23,174,459,40,ID_SLIDER,font);
        SendMessageW(slider,TBM_SETRANGE,TRUE,MAKELONG(0,100));
        SendMessageW(slider,TBM_SETPAGESIZE,0,10);
        control(L"STATIC",L"%0 · Normal",0,30,217,175,22,0,smallFont);
        control(L"STATIC",L"%100 · Tam kırmızı",SS_RIGHT,282,217,193,22,0,smallFont);
        statusLabel=control(L"STATIC",L"Hazırlanıyor…",0,30,257,450,42,0,smallFont);
        control(L"BUTTON",L"Normal",WS_TABSTOP|BS_PUSHBUTTON,30,307,137,38,ID_NORMAL,font);
        control(L"BUTTON",L"Tam kırmızı",WS_TABSTOP|BS_PUSHBUTTON,184,307,137,38,ID_RED,font);
        control(L"BUTTON",L"Arka plana al",WS_TABSTOP|BS_PUSHBUTTON,338,307,137,38,ID_TRAY,font);
        startupBox=control(L"BUTTON",L"Windows ile başlat",WS_TABSTOP|BS_AUTOCHECKBOX,30,367,430,26,ID_STARTUP,font);
        SetWindowTheme(startupBox,L"",L"");
        SendMessageW(startupBox,BM_SETCHECK,isStartupEnabled()?BST_CHECKED:BST_UNCHECKED,0);
        control(L"STATIC",L"Ctrl + Alt + R: aç / kapat    •    Esc: normal renkler",0,30,410,448,24,0,smallFont);
        control(L"STATIC",L"Pencereyi kapatınca önceki ekran renkleri geri yüklenir.",0,30,440,455,24,0,smallFont);
        hotkeyOK=RegisterHotKey(hwnd,ID_HOTKEY,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,'R');
        addTray();
        return 0;
    }
    case WM_HSCROLL:
        if ((HWND)l==slider && !changing) {
            applyIntensity((int)SendMessageW(slider,TBM_GETPOS,0,0),FALSE);
            if (LOWORD(w)==TB_ENDTRACK) saveIntensity();
        }
        return 0;
    case WM_COMMAND:
        switch(LOWORD(w)) {
        case ID_NORMAL: applyIntensity(0,TRUE); break;
        case ID_RED: applyIntensity(100,TRUE); break;
        case ID_TRAY: if(trayAdded) ShowWindow(hwnd,SW_HIDE); else errorBox(L"Bildirim alanı kullanılamıyor."); break;
        case ID_STARTUP: setStartup(SendMessageW(startupBox,BM_GETCHECK,0,0)==BST_CHECKED); break;
        case ID_SHOW: showWindow(); break;
        case ID_EXIT: DestroyWindow(hwnd); break;
        }
        return 0;
    case WM_HOTKEY:
        if(w==ID_HOTKEY) applyIntensity(intensity==0?lastNonzero:0,TRUE);
        return 0;
    case RESETMSG:
        applyIntensity(0,TRUE); showWindow(); return 0;
    case TRAYMSG:
        if(l==WM_LBUTTONUP||l==WM_LBUTTONDBLCLK) showWindow();
        if(l==WM_RBUTTONUP||l==WM_CONTEXTMENU) {
            POINT p; HMENU menu=CreatePopupMenu();
            AppendMenuW(menu,MF_STRING,ID_SHOW,L"Ayarları göster");
            AppendMenuW(menu,MF_STRING,ID_NORMAL,L"Normal renklere dön");
            AppendMenuW(menu,MF_STRING,ID_RED,L"Tam kırmızı");
            AppendMenuW(menu,MF_SEPARATOR,0,NULL);
            AppendMenuW(menu,MF_STRING,ID_EXIT,L"Çıkış ve renkleri geri yükle");
            GetCursorPos(&p); SetForegroundWindow(hwnd);
            TrackPopupMenu(menu,TPM_RIGHTBUTTON,p.x,p.y,0,hwnd,NULL);
            PostMessageW(hwnd,WM_NULL,0,0); DestroyMenu(menu);
        }
        return 0;
    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLORBTN:
        SetTextColor((HDC)w,fg); SetBkColor((HDC)w,bg); return (LRESULT)background;
    case WM_QUERYENDSESSION: return TRUE;
    case WM_ENDSESSION: if(w) {saveIntensity();restore();} return 0;
    case WM_CLOSE: DestroyWindow(hwnd); return 0;
    case WM_DESTROY:
        saveIntensity();restore();
        if (trayAdded) {Shell_NotifyIconW(NIM_DELETE,&tray);trayAdded=FALSE;}
        UnregisterHotKey(hwnd,ID_HOTKEY); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd,msg,w,l);
}
static LONG WINAPI crashHandler(EXCEPTION_POINTERS *info) {
    (void)info; restore(); return EXCEPTION_EXECUTE_HANDLER;
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE previous,LPWSTR command,int show) {
    WNDCLASSEXW wc; RECT rect; MSG msg; HWND existing;
    HANDLE mutex; BOOL reset=(wcsstr(command,L"--reset")!=NULL);
    BOOL startHidden=(wcsstr(command,L"--tray")!=NULL);
    int result=0;
    (void)previous;(void)show;
    instance=h;
    SetProcessDPIAware();
    existing=FindWindowW(APPCLASS,NULL);
    if(existing) {
        if(reset) SendMessageTimeoutW(existing,RESETMSG,0,0,SMTO_ABORTIFHUNG,2000,NULL);
        else { ShowWindow(existing,SW_RESTORE);SetForegroundWindow(existing); }
        return 0;
    }
    mutex=CreateMutexW(NULL,TRUE,L"Local\\TrueRedControllerV1");
    if(!mutex) return 1;
    if(GetLastError()==ERROR_ALREADY_EXISTS) {CloseHandle(mutex);return 0;}
    if(!initEngine()) {
        errorBox(L"Windows renk motoru başlatılamadı. Bu sürüm Windows 10/11 x64 masaüstü içindir.\n\nUzak masaüstü veya uyumsuz ekran sürücüsünde çalışmayabilir.");
        result=1;goto cleanup;
    }
    SetUnhandledExceptionFilter(crashHandler);
    if(reset) {
        ColorMatrix normal;make_color(normal.v,0);
        if(!magSet(&normal)) {errorBox(L"Renkler sıfırlanamadı. Windows oturumunu kapatıp açmayı deneyin.");result=1;}
        else {intensity=0;saveIntensity();}
        goto cleanup;
    }
    {INITCOMMONCONTROLSEX ic={sizeof(ic),ICC_BAR_CLASSES};InitCommonControlsEx(&ic);}
    background=CreateSolidBrush(bg);
    font=CreateFontW(-scale(16),0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    smallFont=CreateFontW(-scale(13),0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    titleFont=CreateFontW(-scale(31),0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    numberFont=CreateFontW(-scale(40),0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    icon=LoadIconW(h,MAKEINTRESOURCEW(1));
    if(!icon) icon=LoadIconW(NULL,IDI_APPLICATION);
    ZeroMemory(&wc,sizeof(wc));wc.cbSize=sizeof(wc);wc.hInstance=h;wc.lpfnWndProc=windowProc;
    wc.lpszClassName=APPCLASS;wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hIcon=icon;wc.hIconSm=icon;wc.hbrBackground=background;
    if(!RegisterClassExW(&wc)){result=1;goto cleanup;}
    rect.left=rect.top=0;rect.right=scale(505);rect.bottom=scale(485);
    AdjustWindowRectEx(&rect,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,FALSE,0);
    taskbarCreated=RegisterWindowMessageW(L"TaskbarCreated");
    mainWindow=CreateWindowExW(0,APPCLASS,L"True Red • Ekran renk kontrolü",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
        CW_USEDEFAULT,CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,NULL,NULL,h,NULL);
    if(!mainWindow){result=1;goto cleanup;}
    if(!applyIntensity((int)readIntensity(),FALSE)) {startHidden=FALSE;}
    ShowWindow(mainWindow,startHidden&&trayAdded?SW_HIDE:SW_SHOW);
    while(GetMessageW(&msg,NULL,0,0)>0) {
        if(msg.message==WM_KEYDOWN&&msg.wParam==VK_ESCAPE) {applyIntensity(0,TRUE);continue;}
        if(!IsDialogMessageW(mainWindow,&msg)) {TranslateMessage(&msg);DispatchMessageW(&msg);}
    }
cleanup:
    if(initialized) magUninit();
    if(magDll) FreeLibrary(magDll);
    if(font) DeleteObject(font);
    if(smallFont) DeleteObject(smallFont);
    if(titleFont) DeleteObject(titleFont);
    if(numberFont) DeleteObject(numberFont);
    if(background) DeleteObject(background);
    ReleaseMutex(mutex);CloseHandle(mutex);
    return result;
}
