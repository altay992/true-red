@echo off
setlocal
cd /d "%~dp0"
windres app.rc -o app-resource.o
if errorlevel 1 exit /b 1
gcc -Wall -Wextra -Werror -O2 -municode -mwindows -static -static-libgcc TrueRed.c app-resource.o -o ..\TrueRed.exe -lcomctl32 -lshell32 -ladvapi32 -lgdi32 -luser32 -luxtheme
