#ifndef TRUERED_COLOR_H
#define TRUERED_COLOR_H
/* Windows MAGCOLOREFFECT uses input rows and output columns. */
static void make_color(float m[25], int intensity) {
    int i;
    float t;
    if (intensity < 0) intensity = 0;
    if (intensity > 100) intensity = 100;
    t = intensity / 100.0f;
    for (i = 0; i < 25; i++) m[i] = 0.0f;
    m[0] = 1.0f - t + t * 0.2126f;
    m[5] = t * 0.7152f;
    m[10] = t * 0.0722f;
    m[6] = m[12] = 1.0f - t;
    m[18] = m[24] = 1.0f;
}
#endif
