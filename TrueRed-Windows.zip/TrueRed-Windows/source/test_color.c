#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "color.h"
int main(void) {
 float m[25]; int p,r,g,b,i;
 make_color(m,0);
 for(i=0;i<25;i++) assert(m[i]==(i%6==0?1.0f:0.0f));
 for(p=0;p<=100;p++) {
  make_color(m,p);
  assert(m[18]==1.0f && m[24]==1.0f);
  for(r=0;r<=1;r++)for(g=0;g<=1;g++)for(b=0;b<=1;b++) {
   float R=r*m[0]+g*m[5]+b*m[10];
   float G=r*m[1]+g*m[6]+b*m[11];
   float B=r*m[2]+g*m[7]+b*m[12];
   assert(R>=0 && R<=1.000001f && G>=0 && G<=1 && B>=0 && B<=1);
   if(p==100) {assert(G==0 && B==0);assert(fabsf(R-(.2126f*r+.7152f*g+.0722f*b))<0.000001f);}
   if(p==50) {assert(fabsf(G-.5f*g)<0.000001f);assert(fabsf(B-.5f*b)<0.000001f);}
  }
 }
 puts("PASS: identity, 101 intensity levels, RGB cube bounds, red-only endpoint, alpha preservation");
 return 0;
}
